/**
 * This is a DEV export for the Webpack dev server
 */

import React from 'react'
import ReactDOM from 'react-dom'
import Component from '../src/index'

ReactDOM.render(<Component />, document.querySelector('#app'))
